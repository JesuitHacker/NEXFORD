1. Import the salary data
2. Function to get employee details
3. Process data using a dictionary
4. Error handling example
5. Export employee details to CSV inside a zipped folder
6. Uses the R script to unzip the folder.

---------------------------------------
https://github.com/JesuitHacker/NEXFORD---------------GITHUB REPO.
---------------------------------------

