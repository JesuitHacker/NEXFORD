How the Program Works:

The program creates a list of 400 workers using a for loop.

Each worker is assigned:

A name

A salary

A gender

The program then loops through all workers and assigns an employee level based on the following rules:

If salary is greater than 10,000 and less than 20,000 → Employee Level A1

If salary is greater than 7,500 and less than 30,000 and the employee is female → Employee Level A5-F

A payment slip is printed for each worker showing their details and assigned level.

Basic error handling is included to prevent the program from crashing if an error occurs.